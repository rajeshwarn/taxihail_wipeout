//
//  ViewController.h
//  ReferenceImplementation
//
//  Created by appledev on 10/15/13.
//  Copyright (c) 2013 Kount. All rights reserved.
//

#import <UIKit/UIKit.h>

//Change this to point to your URL that redirects to the Device Collector
#define DC_TARGET_URL @"https://tst.kaptcha.com/logo.htm"
//Set your merchant ID here
#define DC_MERCHANT_ID @"999999"


@interface ViewController : UIViewController

@end
