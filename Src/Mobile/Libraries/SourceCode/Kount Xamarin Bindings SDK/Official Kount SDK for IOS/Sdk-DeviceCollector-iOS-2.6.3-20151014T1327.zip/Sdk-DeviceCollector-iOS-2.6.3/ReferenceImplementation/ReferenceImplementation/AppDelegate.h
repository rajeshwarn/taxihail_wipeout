//
//  AppDelegate.h
//  ReferenceImplementation
//
//  Created by appledev on 10/15/13.
//  Copyright (c) 2013 Kount. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
