# Kount Device Collector SDK - iOS v. 2.6

The SDK Device Collector iOS provides a static library which can be linked with an iOS application to
perform device collection interaction with Kount for native iOS applications on Apple’s mobile
platforms. The static library is compiled for iOS version 7.0 and newer. It is a bitcode enabled, Mach-O
universal binary for architectures armv7, armv7s, arm64, x86_64, and i386.

## Copyright and License
Copyright &copy; 2012-2015 Kount, Inc. All Rights Reserved.

## What's Included?
Unzipping the provided zip file provides the following file structure:

```
Sdk-DeviceCollector-iOS-<version>/
  |
  |-- DeviceCollectorLibrary/
  |     |
  |     |-- DeviceCollectorSDK.h        : Header file describing library
  |     `-- libDeviceCollectorLibrary.a : Universal static library
  |
  `-- NON-ARC-APP/                      : A reference implementation project with ARC disabled
  `-- README.md                         : This markdown file.
  `-- ReferenceImplementation/          : A reference implementation project
  `-- SwiftReferenceImplementation/     : A reference implementation project written in Swift
```

## Reference Implementations
Along with the Device Collector Library, there are three bare-bones reference applications included showing the fundamentals
needed to use the SDK. They are as follows:

* **ReferenceImplementation** - Objective-C project that is fairly modern and uses ARC.
* **NON-ARC-APP** - Objective-C project that does memory management without ARC.
* **SwiftReferenceImplementation** - Swift project with an Objective-C bridging header to use the Device Collector Library.

The reference implementations are not meant to be used in a production environment. For assistance with production code, please
contact your Merchant Services representative. These examples can be ignored if examples are not needed by the merchant.

## Adding the Device Collector Library to an Objective-C Project
For additional guidance, please refer to the included *ReferenceImplementation* project. For pre-ARC apps,
please refer to the included *NON-ARC-APP* project.

1. Drag and drop the *DeviceCollectorLibrary* folder into your project at the root level.
2. Select your targets in the *Add to targets* section of the file add dialog. Add the library as a group.
3. Add *libDeviceCollectorLibrary.a* to the target's *Link Binary With Libraries*
4. If the application is using the Geolocation collector, add the *NSLocationWhenInUseUsageDescription* key to the *Information Property List* in the
Info.plist file for the project. The value is what will be displayed to the user as the reason the app needs location information. If the Geolocation
collector is not being used, don't forget to add the Geolocation collector to the skipList in step 7.
5. Create or modify a class to implement the DeviceCollectorSDKDelegate protocol. Instantiate a DeviceCollectorSDK and set the delegate using
``- (void)setDelegate:(DeviceCollectorSDKDelegate *)delegate``. This will allow the class to get status callbacks from the library.
6. Call ``- (void)setCollectorUrl:(NSString *)url`` and ``- (void)setMerchantId:(NSString *)mercId`` on the DeviceCollectorSDK object
to set the collector URL and merchant ID respectively.
7. Optionally build a ``NSMutableArray`` of ``NSString`` objects and call ``- (void)setSkipList(NSMutableArray *)list`` on the DeviceCollectorSDK object.
8. Generate a session ID and call ``- (void)collect:(NSString *)sessionId`` on the DeviceCollectorSDK object at the appropriate point in the application.

## Adding the Device Collector Library to a Swift Project
For additional guidance, please refer to the included *SwiftReferenceImplementation* project.

1. Drag and drop the *DeviceCollectorLibrary* folder into your project at the root level.
2. Select your targets in the *Add to targets* section of the file add dialog. Add the library as a group.
3. *File->New->File*. Add an Objective-C file named *ObjectiveCBridgingHeader* as an empty file. XCode will prompt you to create a bridging header.
Create the bridging header.
4. Two files are created in the project. Delete the .m file. It won't be needed. Add the following line to the .h file:

    ```C
    #import "DeviceCollectorSDK.h"
    ```

5. Add *libDeviceCollectorLibrary.a* to the target's *Link Binary With Libraries*
6. If the application is using the Geolocation collector, add the *NSLocationWhenInUseUsageDescription* key to the *Information Property List* in the
Info.plist file for the project. The value is what will be displayed to the user as the reason the app needs location information. If the Geolocation
collector is not being used, don't forget to add the Geolocation collector to the skipList in step 9.

7. Create or modify a class to implement the DeviceCollectorSDKDelegate protocol. Instantiate a DeviceCollectorSDK and set the delegate using
``setDelegate()``. This will allow the class to get status callbacks from the library.
8. Call ``setCollectorURL()`` and ``setMerchantId()`` on the DeviceCollectorSDK to set the collector URL and merchant ID respectively.
9. Optionally set the ``skipList`` property of the DeviceCollectorSDK.
10. Generate a session ID and call ``collect()`` at the appropriate point in the application.


## Using the Device Collector Library to Collect Device Information and Send it to Kount
Implementing the SDK inside your application consists of two basic steps:
1. Creation and Configuration
2. Calling the collect() method

This starts the collection process.

The Creation and Configuration process involves creating the DeviceCollectorSDK object, and setting up the
object with the following values:

- Merchant ID - This is provided to you by Kount.
- Collector URL - This is your Data Collector URL the 302 redirects to the Data Collector (something
like : https://mysite.com/logo.htm). For more information on the Collector URL, see the Data
Collector documentation.
- The DeviceCollectorSDKDelegate implementation - To listen for status changes by the collector.

The SDK collects data in the background after collect() is called.
When you want the collector to gather information about the device, once the DeviceCollector is created
and configured, call the collect() method and pass in the session ID . The collect() method spawns a
background thread to collect device information. The collect() method should not be called until a
transaction is considered "imminent". For examples around what "imminent" means, see the section on
using the collect() method.

When the DeviceCollector collect process starts, it fires the onCollectorStart() method of the delegate if
a delegate exists.

### DeviceCollectorSDKDelegate
The DeviceCollectorSDKDelegate protocol has the following callbacks on it:

```C
// Notification that the collector has started.
- (void) onCollectorStart;

// Notification that the collector finished successfully.
- (void) onCollectorSuccess;

// Notification that an error occurred.
- (void) onCollectorError:(int) errorCode withError:(NSError*) error;
```

When an object implements this protocol and registers with the DeviceCollectorSDK object (by calling ``setDelegate``), it will receive calls indicating the
status of the running collector. Use this mechanism to handle error conditions and to determine when the collector is collecting data from the device.
Implementing this delegate is optional and the collector operates properly if a delegate is not set, but implementation is recommended for error handling
and discovering when the collector has completed.

### Skip List
Within the DeviceCollectorSDK, there are optional collectors that can be run or skipped. Currently, the collectors that can be skipped are:

```C
// Geo Location Collector
#define DC_COLLECTOR_GEO_LOCATION   @"COLLECTOR_GEO_LOCATION"
```
To skip running an optional collector, set the skipList property on the DeviceCollectorSDK with an array of collector names to skip.

### Calling Collect
It is important to collect the most up-to-date information possible just before a payment method is used.
In the realm of shopping carts on a web site, this is normally at the checkout step. On the checkout page,
a merchant displays order information the user would like to submit and also displays and gathers last
minute information like method of payment or billing/shipping information. Work flow models differ, but
generally there is a page that allows the user to confirm their purchase prior to the transaction submission
to the processing server. Our suggestion is to execute the collect() method in this review step ("prior to"
or "as" the review step is being displayed). The call to collect() should be performed on the main thread.

The collection process starts when you call the collect(session ID) method of the DeviceCollector. This
process runs asynchronously in the background and should not stop or interrupt your application.

The collect() call should only happen once per transaction.

If your application resets (i.e. due to an orientation change) you should keep track of whether or not you
have already called collect(). The collector will notify your listener, if implemented, of the changes in
status as things move along, which you can react to or ignore.

The calling application does not need to wait for the completion of the DeviceCollector. If the DeviceCollector
does not complete prior to a call to the Risk Inquiry System (RIS) for the same transaction (session
ID), then the DeviceCollector information will not be used. This prevents any "gating" effects to the
application from the collector.


## Error Codes
On error conditions, the Device Collector Library will call onCollectorError on the DeviceCollectorSDKDelegate with a numerically coded error.
These can be found in the DeviceCollectorSDK.h header:

```C
#define DC_ERR_NSERROR            1  // NSError trapped. See error for details
#define DC_ERR_NONETWORK          2  // Network access not available
#define DC_ERR_INVALID_URL        3  // Invalid collector URL
#define DC_ERR_INVALID_MERCHANT   4  // Invalid Merchant Id
#define DC_ERR_INVALID_SESSION    5  // Invalid Session Id
#define DC_ERR_VALIDATION_FAILURE 6  // Device collection failed
```

## Frequently Asked Questions

**QUESTION:** Why does onCollectorError get called when attempting to collect data?

**ANSWER:** Have you verified that your *Merchant ID*, *Session ID*, and *CollectorURLs* are set correctly
(errorCodes 4, 5 and 3 respectively)? The *Merchant ID* must be the 6 digit number supplied to you from Kount. The
*Session ID* is a 32 character string unique to this session provided by you. The Collector URL (with HTTPS) must be a fully
qualified URL that points to a resource, not just a server (i.e. *https://mysite.com/logo.htm*, not just *https://mysite.com*)
Also, have you setup your Data Collector URL within your framework to 302 redirect to the KOUNT_SERVER_URL?

From *https://mysite.com/logo.htm* -> *https://KOUNT_SERVER/logo.htm*

A misconfiguration in the Data Collector URL can also cause a general failure in device collection (errorCode 6).
If you turn debugging on, you should see it send a message to the logs showing the final URL it is trying
to use. If your input is:

- Merchant ID: **123456**
- Collector URL(HTTPS) : **<https://mysite.com/logo.htm>**
- Session ID: **ABCD123456789ABCDFFEEDD123456732**

Then the final final URL posted to the logs (in debug mode) should look something like this:

**<https://mysite.com/logo.htm?m=123456&s=ABCD123456789ABCDFFEEDD123456732>**

If this still does not work, try copying and pasting this URL to a web browser and ensure the logo you
have provided merchant services displays on the return page. If you do not get your logo to display:

1. Check to ensure you correctly setup the Data Collector redirect on your servers
( i.e. from *https://mysite.com/logo.htm* -> *https://KOUNT_SERVER/logo.htm* )
2. If your redirect is working, the there may be an issue with your account. Contact Merchant Services
to troubleshoot. Please include the URL you are using above.

## Change Log
### 2.6.3 (Current)
- Included a reference implementation done in the Swift language.
- All reference implementations now build out of the box; automatically linking with the provided DeviceCollectorLibrary.
- Updated the Readme.
- Removed optional DC_COLLECTOR_DEVICE_ID collector since it hasn't been supported since iOS 7.
- Fixed a bug where onCollectorSuccess() would get called before the data post had returned.

### 2.6.2
- More changes in compiler flags to further remove the large amount of warnings merchants were seeing when building.
- Updated the DeviceCollectorSDK.h file.

### 2.6.1
- Changes in compiler flags to remove the large amount of warnings merchants were seeing when building.

### 2.6.0
- Updated for iOS 9. Minimum iOS supported moved to iOS 7.

