//
//  ViewController.m
//  Non ARC APP
//
//  Created by appledev on 10/14/13.
//  Copyright (c) 2013 appledev. All rights reserved.
//

#import "ViewController.h"
#import "DeviceCollectorSDK.h"


@interface ViewController () <DeviceCollectorSDKDelegate>
@property (nonatomic, retain) DeviceCollectorSDK *deviceCollector;
@property (strong, nonatomic) IBOutlet UITextView *logView;
@property (nonatomic, strong) NSString *logText;

@end

@implementation ViewController

@synthesize myButton;
@synthesize deviceCollector = _deviceCollector;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClick:(UIButton *)sender {
    NSString *sessionId;
    CFUUIDRef uuidRef = CFUUIDCreate(nil);
    CFStringRef uuidStrRef = CFUUIDCreateString(nil, uuidRef);
    CFRelease(uuidRef);
    // - Strip the hyphens out of the generated string
    sessionId = [(__bridge NSString *)uuidStrRef
                  stringByReplacingOccurrencesOfString:@"-"
                  withString:@""];
    CFRelease(uuidStrRef);
    [self addStatusMessage:[NSString stringWithFormat:@"Calling collect with SessionID:%@", sessionId]];
    // 3) Get the unique session identifier that will be used to correlate the
    // Device Collector data with the subsequent RIS request sent by your backend
    // application.
    //
    // See the "Kount® Technical Specifications Guide" for more
    // details.
    // 4) Invoke the DeviceCollector.
    // This will asynchronously perform the device collection work. Your view
    // will receive notification of start and success or failure via the
    // protocol messages we registered for earlier.
    [self.deviceCollector collect:sessionId];
}


- (void) addStatusMessage:(NSString *) message {
    if (!self.logText) {
      self.logText = @"";
    }
    NSString *msg = [NSString stringWithFormat:@"%@ - %@\n", [NSDate date], message];
    NSLog(@"%@", msg);
    self.logText = [self.logText stringByAppendingString:msg];
    [self.logView setText:self.logText];
}

- (DeviceCollectorSDK *) deviceCollector {
    if (!_deviceCollector) {
        _deviceCollector = [[DeviceCollectorSDK alloc] initWithDebugOn:YES];
        [_deviceCollector setCollectorUrl:DC_TARGET_URL];
        [_deviceCollector setMerchantId:DC_MERCHANT_ID];
        [_deviceCollector setDelegate:self];
        [self addStatusMessage:@"Created Collector"];
    }
    return _deviceCollector;
} // end deviceCollector

#pragma mark - memory clearing
- (void) clearMemory {
    [self addStatusMessage:@"Deallocating Objects"];
    [self.deviceCollector setDelegate:nil];
    self.deviceCollector = nil;
    [self addStatusMessage:@"DeviceCollector is nil"];
    [self addStatusMessage:@"Cleared Memory"];
}

#pragma mark DeviceCollectorSDKDelegate implementation

- (void)onCollectorStart {
    [self addStatusMessage:@"Collector Started"];
}

-(void)onCollectorSuccess {
    [self addStatusMessage:@"Collector Finished"];
    [self addStatusMessage:@"All Done"];
    [self clearMemory];
}

- (void) onCollectorError:(int)errorCode withError:(NSError *)error {
    [self addStatusMessage:
    [NSString stringWithFormat:@"\nError:%d %@", errorCode, error]];
}


- (void)dealloc {
  [_logView release];
  [super dealloc];
}
@end
