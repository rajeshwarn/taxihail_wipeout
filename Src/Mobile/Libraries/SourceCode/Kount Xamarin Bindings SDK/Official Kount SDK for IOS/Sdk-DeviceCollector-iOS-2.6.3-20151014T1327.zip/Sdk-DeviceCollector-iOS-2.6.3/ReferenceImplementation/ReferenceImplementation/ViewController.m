//
//  ViewController.m
//  ReferenceImplementation
//
//  Created by appledev on 10/15/13.
//  Copyright (c) 2013 Kount. All rights reserved.
//

#import "ViewController.h"
#import "DeviceCollectorSDK.h"

@interface ViewController ()  <DeviceCollectorSDKDelegate>
@property (weak, nonatomic) IBOutlet UIButton *clickButton;
@property (weak, nonatomic) IBOutlet UITextView *logView;
@property (nonatomic) DeviceCollectorSDK *deviceCollector;
@property (nonatomic, strong) NSString *logText;

@end

@implementation ViewController

@synthesize clickButton;
@synthesize deviceCollector = _deviceCollector;

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Make button pretty
    CALayer *btnLayer = [self.clickButton layer];
    [btnLayer setMasksToBounds:YES];
    [btnLayer setCornerRadius:5.0f];

	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClick:(UIButton *)sender {
    NSString *sessionId;
    CFUUIDRef uuidRef = CFUUIDCreate(nil);
    CFStringRef uuidStrRef = CFUUIDCreateString(nil, uuidRef);
    CFRelease(uuidRef);
    // - Strip the hyphens out of the generated string
    sessionId = [(__bridge NSString *)uuidStrRef
                 stringByReplacingOccurrencesOfString:@"-"
                 withString:@""];
    CFRelease(uuidStrRef);
    [self addStatusMessage:[NSString stringWithFormat:@"SessionID: %@", sessionId]];
    [self addStatusMessage:@"Calling collect"];
    // 3) Get the unique session identifier that will be used to correlate the
    // Device Collector data with the subsequent RIS request sent by your backend
    // application.
    //
    // See the "Kount® Technical Specifications Guide" for more
    // details.
    // 4) Invoke the DeviceCollector.
    // This will asynchronously perform the device collection work. Your view
    // will receive notification of start and success or failure via the
    // protocol messages we registered for earlier.
    [self.deviceCollector collect:sessionId];
}


- (void) addStatusMessage:(NSString *) message {
    if (!self.logText) {
      self.logText = @"";
    }
    NSString *msg = [NSString stringWithFormat:@"%@ - %@\n", [NSDate date], message];
    self.logText = [self.logText stringByAppendingString:msg];
    NSLog(@"%@", msg);
    [self.logView setText:self.logText];
}

- (DeviceCollectorSDK *) deviceCollector {
    if (!_deviceCollector) {
        _deviceCollector = [[DeviceCollectorSDK alloc] initWithDebugOn:YES ];
        [_deviceCollector setCollectorUrl:DC_TARGET_URL];
        [_deviceCollector setMerchantId:DC_MERCHANT_ID];
        [_deviceCollector setDelegate:self];
        NSMutableArray *skipList = [[NSMutableArray alloc]init];
        // Uncomment following line to skip the geo location collector.
        //[skipList addObject:DC_COLLECTOR_GEO_LOCATION];
        [self.deviceCollector setSkipList:skipList];
        [self addStatusMessage:@"Created DeviceCollector"];
    }
    return _deviceCollector;
} // end deviceCollector

#pragma mark DeviceCollectorSDKDelegate implementation

- (void)onCollectorStart {
    [self addStatusMessage:@"Collector Started"];
}

-(void)onCollectorSuccess {
    [self addStatusMessage:@"Collector Finished"];
    [self addStatusMessage:@"All Done"];
}

- (void) onCollectorError:(int)errorCode withError:(NSError *)error {
    [self addStatusMessage:
     [NSString stringWithFormat:@"Collector finished with error: %@, error code %d",
      [error description], errorCode]];
}

@end
