//
//  ViewController.h
//  Non ARC APP
//
//  Created by appledev on 10/14/13.
//  Copyright (c) 2013 appledev. All rights reserved.
//

#import <UIKit/UIKit.h>

//Cheange this to point to your URL that redirects to the Device Collector
#define DC_TARGET_URL @"https://tst.kaptcha.com/logo.htm"
//Set your merchant ID here
#define DC_MERCHANT_ID @"999999"

@interface ViewController : UIViewController

@property (assign, nonatomic) IBOutlet UIButton *myButton;

@end
