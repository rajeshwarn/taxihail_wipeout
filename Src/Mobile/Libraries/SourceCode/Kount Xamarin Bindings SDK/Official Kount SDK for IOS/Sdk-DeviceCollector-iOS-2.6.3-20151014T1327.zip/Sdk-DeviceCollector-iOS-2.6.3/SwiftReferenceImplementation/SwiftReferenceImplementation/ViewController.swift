//
//  ViewController.swift
//  Swift-Reference-App
//
//  Created by Pete Neisen on 9/29/15.
//  Copyright © 2015 Kount. All rights reserved.
//

import UIKit

// Change this to point to your URL that redirects to the Device Collector
let collectorURL = "https://tst.kaptcha.com/logo.htm"
// Set your merchant ID here
let merchantID = "999999"

class ViewController: UIViewController, DeviceCollectorSDKDelegate {
  
  var deviceCollector: DeviceCollectorSDK = DeviceCollectorSDK(debugOn: true)
  
  func addStatusMessage (message: String) {
    statusText.text = statusText.text + "🔷 " + String(NSDate().timeIntervalSince1970) + " - " + message + "\n"
  }
  
  func getSessionId() -> String {
    return NSUUID().UUIDString.stringByReplacingOccurrencesOfString("-", withString: "")
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }
  
  // MARK: Properties
  @IBOutlet weak var statusText: UITextView!
  
  // MARK: Actions
  @IBAction func collectClicked(sender: UIButton) {
    
    // Setup the collector
    deviceCollector.setCollectorUrl(collectorURL)
    deviceCollector.setMerchantId(merchantID)
    deviceCollector.skipList = [
    //  "COLLECTOR_GEO_LOCATION"
    ]
    deviceCollector.setDelegate(self)
    
    // Start the collection
    let sess = getSessionId()
    addStatusMessage("Starting collector with sess=\(sess)")
    deviceCollector.collect(sess)
  }
  
  // MARK: DeviceCollectorSDKDelegate
  func onCollectorStart() {
    addStatusMessage("Collector started")
  }
  
  func onCollectorSuccess() {
    addStatusMessage("Collector successful")
  }
  
  func onCollectorError(errorCode: Int32, withError error: NSError!) {
    if (error != nil) {
      addStatusMessage("Error: \(errorCode): \(error.description)")
    } else {
        addStatusMessage("Error: \(errorCode): (no message)")
    }
  }
}

