package example.androidcheckouttest;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.devicecollector.DeviceCollector;
import com.devicecollector.DeviceCollector.ErrorCode;
import com.devicecollector.collectors.CollectorEnum;

import java.util.Date;
import java.util.EnumSet;
import java.util.UUID;

/**
 * Example Headless Fragement implementation for API 11 and higher.
 * 
 * @author Kount <custserv@kount.com>
 * @version SVN: $Id$
 * @copyright 2013 Kount, Inc. All Rights Reserved.
 */
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class CheckoutFragment extends Fragment implements
    DeviceCollector.StatusListener {

  private static final String svnID = "$Id$";
  private DeviceCollector dc;
  private static final String LOG_TAG = "CheckoutFragment";
  private StringBuffer message = new StringBuffer("Waiting on user\n");
  private Date startTime = new Date();
  /**
   * Whether the Device Collector is currently running.
   */
  private boolean running = false;
  /**
   * Whether the Device Collector completed.
   */
  private boolean finished = false;

  /**
   * Session ID. Also to be used by RIS later when the transaction is sent to be
   * scored and completed.
   */
  private String sessionId;

  /**
   * Fragment initialization. We want to be retained.
   */
  @Override
  public void onCreate (Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    this.debug("QA Testing Project "
            + CheckoutFragment.svnID 
            + " - with Fragments - SDK Version:" + 
        DeviceCollector.VERSION + "\n");

    // Tell the framework to try to keep this fragment around
    // during a configuration change.
    this.setRetainInstance(true);

  }

  /**
   * This is called right before the fragment is detached from its current
   * activity instance.
   */
  @Override
  public void onDetach () {
    this.debug("Detaching....\n");
    // call the parent
    super.onDetach();
  }

  /**
   * Gets the sesisonID.
   * 
   * @return The sessionId passed to the DeviceCollector.
   */
  public String getSessionId () {
    return this.sessionId;
  }

  /**
   * Tell the library to stop immediately.
   */
  public void cancel () {
    if (!this.finished && this.running && null != this.dc) {
      this.debug("Trying to stop...\n");
      this.dc.stopNow();
      this.debug("Stopping complete!\n");
    }else {
      this.debug("Nothing to stop\n");
    }
  } // end stopNow ()

  /**
   * Handle the checkout
   * 
   * @param view
   */
  public void checkout () {
    // Check if we are already running
    if (!this.running) {
      // Check if we already finished
      if (!this.finished) {
        // Create a sessionID (Unique ID) that doesn't repeat over a 30 day
        // period per transaction
        this.sessionId = UUID.randomUUID().toString();
        // The device collector does not like special characters in the
        // sessionID, so let's strip them out
        // we should store this sessionId somewhere so we can pass it to
        // whatever is making the RIS call down the line.
        this.sessionId = this.sessionId.replace("-", "");

        // No saved instances, create a new one
        this.dc = new DeviceCollector(this.getActivity());

        this.dc.setStatusListener(this);

        //set the merchantID
        EditText merchantIdField = (EditText)getActivity().findViewById(R.id.merchantIdField);
        this.dc.setMerchantId(merchantIdField.getText().toString());

        // Set the Public site testing URL
        EditText merchantUrlField = (EditText)getActivity().findViewById(R.id.merchantUrlField);
        this.dc.setCollectorUrl(merchantUrlField.getText().toString());

        //Set the timeout
        EditText timeoutField = (EditText)getActivity().findViewById(R.id.timeoutField);
        long timeout = Long.parseLong(timeoutField.getText().toString());
        
        CheckBox geoCheckbox = (CheckBox)getActivity().findViewById(R.id.geoCheck);
        CheckBox macCheckbox = (CheckBox)getActivity().findViewById(R.id.macCheck);
        // Skipping Collectors
        if (!geoCheckbox.isChecked() || !macCheckbox.isChecked()) {
          EnumSet<CollectorEnum> skipList = null;
          if(!geoCheckbox.isChecked() && !macCheckbox.isChecked()) {
            skipList = EnumSet.of(
                    CollectorEnum.GEO_LOCATION,
                    CollectorEnum.MAC_ADDRESS);
          }else if (!geoCheckbox.isChecked()) {
            skipList = EnumSet.of(CollectorEnum.GEO_LOCATION);
          } else {
            skipList = EnumSet.of(CollectorEnum.MAC_ADDRESS);
            
          }
          this.debug("\nSkipping [" + skipList + "]\n");
          dc.skipCollectors(skipList);
        }

        this.debug("Checking out with sessionid [" + this.sessionId + "]" +
            "\ntimeout[" + timeout + "]" +
            "\nFor merchant["+ merchantIdField.getText().toString()+"]" +
            "\nUsing url["+ merchantUrlField.getText().toString()+"]\n");
        // Start collecting
        this.startTime = new Date();
        this.dc.collect(this.sessionId, timeout);

      } else {
        this.debug("Already completed for this transaction. Why are you"
            + "trying to run again?\n");
      } // end if (!this.finished) / else

    } else {
      this.debug("Already running\n");
    } // end if (!this.running) / else
  } // end checkout (View view)

  /**
   * Implementation of handling an error coming from the collector.
   * 
   * @param code
   *          The Error code returned
   * @param ex
   *          The Exception that caused the code.
   */

  @Override
  public void onCollectorError (ErrorCode code, Exception ex) {
   long totalTime = getTotalTime();
   this.finished = true;
    if (null != ex) {
      if (code.equals(ErrorCode.MERCHANT_CANCELLED)) {
        this.debug("Merchant Cancelled\n");
      } else {
        this.debug("Collector Failed in (" + totalTime + 
            ") ms. It had an error [" + code + "]:" + ex.getMessage());
        this.debug("Stack Trace:");
        for (StackTraceElement element : ex.getStackTrace()) {
          this.debug(element.getClassName() + " " + element.getMethodName()
              + "(" + element.getLineNumber() + ")");
        } // end for (StackTraceElement element : ex.getStackTrace())
      } // end if (code.equals(ErrorCode.MERCHANT_CANCELLED)) / else
    } else {
      this.debug("Collector failed in (" + totalTime + 
          ") ms. It had an error [" + code + "]:");
    } // end if (null != ex) / else
  } // end onCollectorError (ErrorCode code, Exception ex)

  /**
   * Implementation of handling collection start. In this case we are just
   * logging, and marking a flag as running.
   */
  @Override
  public void onCollectorStart () {
    long totalTime = getTotalTime();
    this.debug("Starting collector ("+totalTime+")ms....\n");
    this.running = true;
  } // end onCollectorStart ()

  /**
   * Implementation of handling collection start. In this case we are just
   * logging, and marking a flag as not running.
   */
  @Override
  public void onCollectorSuccess () {
    long totalTime = getTotalTime();
    this.debug("Collector finished successfully in (" + totalTime+ ") ms\n");
    this.running = false;
    this.finished = true;
    this.setRetainInstance(false);
    // Let other processes know it's all done here

  } // end onCollectorSuccess ()

  /*
   * Gets the time difference between when the dc.collect() was called and now. 
   * @return Time difference in milliseconds
   */
  private long getTotalTime() {
    Date stopTime = new Date();
    return stopTime.getTime() - startTime.getTime();
  }

  /*
   * Debug messages. Send to the view and to the logs.
   * @param message The message to pass to the view and logs
   */
  private void debug (String msg) {
    this.message.append(msg);
    Log.v(CheckoutFragment.LOG_TAG, msg);
    if(this.getActivity() != null) {
      this.getActivity().runOnUiThread(new Runnable() {
  
        @Override
        public void run () {
          TextView tv = (TextView) CheckoutFragment.this.getActivity()
              .findViewById(R.id.resultsTextView);
          tv.setText(CheckoutFragment.this.message);
        }
      }); // end runOnUiThread(...))
    }
  } // end debug (String message)

}
