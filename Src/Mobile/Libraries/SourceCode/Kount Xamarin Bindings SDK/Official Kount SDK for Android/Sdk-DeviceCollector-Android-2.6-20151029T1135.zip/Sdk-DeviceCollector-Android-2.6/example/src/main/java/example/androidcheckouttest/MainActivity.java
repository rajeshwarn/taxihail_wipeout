package example.androidcheckouttest;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.devicecollector.DeviceCollector;
import com.devicecollector.collectors.CollectorEnum;

import java.util.Date;
import java.util.EnumSet;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements DeviceCollector.StatusListener {

    private static final String svnID = "$Id$";
    private DeviceCollector dc;
    private static final String LOG_TAG = "CheckoutTestActivity";
    private boolean running = false;
    private boolean finished = false;
    private String message;
    private Date startTime;

    private static final int SDK_PERMISSIONS_REQUEST_FINE_LOC = 77;

    /**
     * on Create implementation
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_main);
        // try to restore a currently active DC, and see if it's still running

        if (this.getLastNonConfigurationInstance() != null) {
            this.debug("Restoring...");
            this.dc = (DeviceCollector) this.getLastNonConfigurationInstance();
            this.dc.setStatusListener(this);
            TextView tv = (TextView) this.findViewById(R.id.resultsTextView);
            tv.setText(savedInstanceState.getCharSequence("uiText"));
            this.running = savedInstanceState.getBoolean("running");
            this.finished = savedInstanceState.getBoolean("finished");

        } else {
            this.debug("Building new...");
            // No saved instances, create a new one
            this.dc = new DeviceCollector(this);
            this.debug("QA Testing Project " + MainActivity.svnID
                    + " - no Fragments - SDK Version:"
                    + DeviceCollector.VERSION + "\n");
            this.dc.setStatusListener(this);
        }

        //See if we have to check for runtime permissions
        if(Build.VERSION.SDK_INT > 22) {
            int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
            if (PackageManager.PERMISSION_DENIED == permissionCheck) {
                // Should we show an explanation?
                this.debug("Asking Permission to use location");
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, SDK_PERMISSIONS_REQUEST_FINE_LOC);
                //exit out of function ... waiting for onRequestPermissionsResult() to trigger
                return;
            } else {
                this.debug("Already have permissions");
            }
        } else {
            // Pre-Marshmallow(API 23) - We already got permissions at install time.
            this.debug("Don't need permissions... getting location directly");
        }

        this.debug("Done creating");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case SDK_PERMISSIONS_REQUEST_FINE_LOC: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    this.debug("Got Permission!");
                } else {
                    this.debug("Permission Denied!");
                    //Skipping Geo location altogether
                    EnumSet<CollectorEnum> skipped = EnumSet.of(
                            CollectorEnum.GEO_LOCATION);
                    this.dc.skipCollectors(skipped);
                }
            }
        }
    }

    /**
     * Handle on onPause
     */
    @Override
    protected void onPause () {
        this.debug("On Pause");
        super.onPause();
    } // end onPause ()

    /**
     * Handle on onStop
     */
    @Override
    protected void onStop () {
        this.debug("On Stop");
        super.onStop();
    } // end onStop ()

    /**
     * Handle on onDestroy
     */
    protected void onDestroy () {
        this.debug("On Destroy");
        super.onDestroy();
    } // end onDestroy ()

//    /**
//     * Only save the configuration if it is not finished, the DeviceCollector is
//     * created and running. This is only for older applications. Aplications using
//     * API 11 or newer, should use Fragments instead. See
//     * http://developer.android.com/guide/components/fragments.html using the
//     * onSaveInstanceState() method.
//     */
//    @Override
//    public Object onRetainNonConfigurationInstance () {
//        if (!this.finished && this.dc != null && this.running) {
//            this.debug("Persiting the Collector");
//            return this.dc;
//        }
//        this.debug("No Need to persist");
//        return null;
//    }

    /**
     * Saving bundle state before the Activity gets destroyed.
     *
     * @param toSave
     *          The Bundle from the activity to persist to.
     */
    @Override
    public void onSaveInstanceState (Bundle toSave) {
        TextView tv = (TextView) this.findViewById(R.id.resultsTextView);
        toSave.putCharSequence("uiText", tv.getText());
        toSave.putBoolean("finished", this.finished);
        toSave.putBoolean("running", this.running);
    } // end onSaveInstanceState(Bundle toSave)

    /**
     * Tell the library to stop immediately.
     */
    public void stopNow (View view) {
        if (!this.finished && this.running && null != this.dc) {
            this.dc.stopNow();
        }
    } // end stopNow ()

    /**
     * Handle the checkout
     *
     * @param view
     */
    public void checkout (View view) {
        // Check if we are already running
        if (!this.running) {
            // Check if we already finished
            if (!this.finished) {
                // Create a sessionID (Unique ID) that doesn't repeat over a 30 day
                // period per transaction
                String sessionId = UUID.randomUUID().toString();
                // The device collector does not like special characters in the
                // sessionID, so let's strip them out
                sessionId = sessionId.replace("-", "");
                //set the merchantID
                EditText merchantIdField = (EditText)this.findViewById(R.id.merchantIdField);
                this.dc.setMerchantId(merchantIdField.getText().toString());

                // Set the Public site testing URL
                EditText merchantUrlField = (EditText)this.findViewById(R.id.merchantUrlField);
                this.dc.setCollectorUrl(merchantUrlField.getText().toString());

                //Set the timeout
                EditText timeoutField = (EditText)this.findViewById(R.id.timeoutField);
                long timeout = Long.parseLong(timeoutField.getText().toString());

                CheckBox geoCheckbox = (CheckBox)this.findViewById(R.id.geoCheck);
                CheckBox macCheckbox = (CheckBox)this.findViewById(R.id.macCheck);
                // Skipping Collectors
                if (!geoCheckbox.isChecked() || !macCheckbox.isChecked()) {
                    EnumSet<CollectorEnum> skipList = null;
                    if(!geoCheckbox.isChecked() && !macCheckbox.isChecked()) {
                        skipList = EnumSet.of(
                                CollectorEnum.GEO_LOCATION,
                                CollectorEnum.MAC_ADDRESS);
                    }else if (!geoCheckbox.isChecked()) {
                        skipList = EnumSet.of(CollectorEnum.GEO_LOCATION);
                    } else {
                        skipList = EnumSet.of(CollectorEnum.MAC_ADDRESS);

                    }
                    this.debug("\nSkipping [" + skipList + "]\n");
                    dc.skipCollectors(skipList);
                }

                this.debug("Checking out with sessionid [" + sessionId + "]" +
                        "\ntimeout[" + timeout + "]" +
                        "\nFor merchant["+ merchantIdField.getText().toString()+"]" +
                        "\nUsing url["+ merchantUrlField.getText().toString()+"]\n");
                this.startTime = new Date();
                this.dc.collect(sessionId, timeout);
                // we should store this sessionId somewhere so we can pass it to
                // whatever is making the RIS call down the line.
            } else {
                this.debug("Already completed for this transaction. Why are you"
                        + "trying to run again?");
            } // end if (!this.finished) / else

        } else {
            this.debug("Already running");
        } // end if (!this.running) / else
    } // end checkout (View view)

    /**
     * Implementation of handling an error coming from the collector.
     *
     * @param code
     *          The Error code returned
     * @param ex
     *          The Exception that caused the code.
     */

    @Override
    public void onCollectorError (DeviceCollector.ErrorCode code, Exception ex) {
        long totalTime = getTotalTime();

        this.finished = true;
        if (null != ex) {
            if (code.equals(DeviceCollector.ErrorCode.MERCHANT_CANCELLED)) {
                this.debug("Merchant Cancelled");
            } else {
                this.debug("Collector Failed in (" + totalTime +
                        ") ms. It had an error [" + code + "]:" + ex.getMessage());
                this.debug("Stack Trace:");
                for (StackTraceElement element : ex.getStackTrace()) {
                    this.debug(element.getClassName() + " " + element.getMethodName()
                            + "(" + element.getLineNumber() + ")");
                } // end for (StackTraceElement element : ex.getStackTrace())
            } // end if (code.equals(ErrorCode.MERCHANT_CANCELLED)) / else
        } else {
            this.debug("Collector failed in (" + totalTime +
                    ") ms. It had an error [" + code + "]:");
        } // end if (null != ex) / else
    } // end onCollectorError (ErrorCode code, Exception ex)

    /**
     * Implementation of handling collection start. In this case we are just
     * logging, and marking a flag as running.
     */
    @Override
    public void onCollectorStart () {
        long totalTime = getTotalTime();
        this.debug("Starting collector ("+totalTime+")ms....");
        this.running = true;
    } // end onCollectorStart ()

    /**
     * Implementation of handling collection start. In this case we are just
     * logging, and marking a flag as not running.
     */
    @Override
    public void onCollectorSuccess () {
        long totalTime = getTotalTime();
        this.debug("Collector finished successfully in (" + totalTime+ ") ms");
        this.running = false;
        this.finished = true;
        // Let other processes know it's all done here

    } // end onCollectorSuccess ()

    private long getTotalTime() {
        Date stopTime = new Date();
        return stopTime.getTime() - startTime.getTime();
    }

    /*
     * Debug messages. Send to the view and to the logs.
     * @param message The message to pass to the view and logs
     */
    private void debug (String message) {
        this.message = message;
        this.runOnUiThread(new Runnable() {

            @Override
            public void run () {
                Log.d(MainActivity.LOG_TAG, MainActivity.this.message);
                TextView tv = (TextView) MainActivity.this
                        .findViewById(R.id.resultsTextView);
                tv.append(MainActivity.this.message);
            }
        }); // end runOnUiThread(...)
    } // end debug (String message)
} // end MainActivity
