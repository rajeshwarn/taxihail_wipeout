package example.androidcheckouttest;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

/**
 * Test Main activity. This activity creates a checkout button and shows the
 * user the status of the test. It will utilize a collector to pass information
 * from the mobile device to the Device Collector server. This is a reference
 * implementation test, and should not be considered production quality code.
 *
 * This is the newer version of the main activity for Target APIs of HONEYCOMB
 * and newer.  If you plan to target a newer API you should use Fragments like
 * this example.
 *
 * @author Kount <custserv@kount.com>
 * @version SVN: $Id$
 * @copyright 2013 Kount, Inc. All Rights Reserved.
 */
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class MainActivityWithFragment extends Activity {

  private CheckoutFragment deviceCollectorFragment;
  private String message;

  /**
   * The on Create implementation.
   * 
   * @param savedInstanceState
   */
  @Override
  protected void onCreate (Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    this.setContentView(R.layout.activity_main);
    FragmentManager fm = this.getFragmentManager();
    // Check to see if we have retained the worker fragment.
    this.deviceCollectorFragment = (CheckoutFragment) fm
        .findFragmentByTag("DeviceCollector");
    // If not retained (or first time running), we need to create it.
    if (this.deviceCollectorFragment == null) {
      this.deviceCollectorFragment = new CheckoutFragment();
      fm.beginTransaction()
          .add(this.deviceCollectorFragment, "DeviceCollector").commit();
    }
    this.debug("Done creating\n");
  }

  /**
   * Handle on onPause
   */
  @Override
  protected void onPause () {
    super.onPause();
    this.debug("On Pause\n");
  } // end onPause ()

  /**
   * Handle on onStop
   */
  @Override
  protected void onStop () {
    super.onStop();
    this.debug("On Stop\n");
  } // end onStop ()

  /**
   * Handle on onDestroy
   */
  @Override
  protected void onDestroy () {
    this.debug("On Destroy\n");
    this.deviceCollectorFragment.cancel();
    this.debug("On Destroy Finished\n");
    super.onDestroy();
  } // end onDestroy ()

  /**
   * Tell the library to stop immediately.
   */
  public void stopNow (View view) {
    this.deviceCollectorFragment.cancel();
  } // end stopNow ()

  /**
   * Handle the checkout
   * 
   * @param view
   */
  public void checkout (View view) {
    // Check if we are already running
    this.deviceCollectorFragment.checkout();
  } // end checkout (View view)

  /*
   * Debug messages. Send to the view and to the logs.
   * @param message The message to pass to the view and logs
   */
  private void debug (String msg) {
    this.message = msg;
    this.runOnUiThread(new Runnable() {

      @Override
      public void run () {
        Log.d("MainActivityWithFragment", MainActivityWithFragment.this.message);
        TextView tv = (TextView) MainActivityWithFragment.this
            .findViewById(R.id.resultsTextView);
        tv.append(MainActivityWithFragment.this.message);
      }
    }); // end runOnUiThread(...)
  } // end debug (String message)
} // end MainActivity
